import java.util.*;
import java.lang.Math;
class Main {
  public static void main(String[] args) {
    System.out.println("Dibuje un poligono ingresando las coordinadas generadas.");

    //Coordenadas generadas
    String LinkPrimario = "https://www.keene.edu/campus/maps/tool/?coordinates=";
     String intermedioVariable = "%2C%20";
    String finalVariable = "%0A";
    String resultado;

    Double x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7;


    Scanner lector = new Scanner(System.in);
    System.out.print("Ingresa un coordinada en x1: ");
    x1 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y1: ");
    y1 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en x2: ");
    x2 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y2: ");
    y2 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en x3: ");
    x3 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y3: ");
    y3 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en x4: ");
    x4 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y4: ");
    y4 = lector.nextDouble();
     System.out.print("Ingresa un coordinada en x5: ");
    x5 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y5: ");
    y5 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en x6: ");
    x6 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y6: ");
    y6 = lector.nextDouble();
     System.out.print("Ingresa un coordinada en x7: ");
    x7 = lector.nextDouble();
    System.out.print("Ingresa un coordinada en y7: ");
    y7 = lector.nextDouble();

    resultado = LinkPrimario + Double.toString(x1)+intermedioVariable + Double.toString(y1) + finalVariable + Double.toString(x2) + intermedioVariable + Double.toString(y2)+ finalVariable + Double.toString(x3) + intermedioVariable + Double.toString(y3) + finalVariable + Double.toString(x4) + intermedioVariable + Double.toString(y4) + finalVariable + Double.toString(x5) + intermedioVariable + Double.toString(y5) + finalVariable + Double.toString(x6) + intermedioVariable + Double.toString(y6) + finalVariable + Double.toString(x7) + intermedioVariable + Double.toString(y7);

     System.out.println("El link es: " +  resultado);
  }
}